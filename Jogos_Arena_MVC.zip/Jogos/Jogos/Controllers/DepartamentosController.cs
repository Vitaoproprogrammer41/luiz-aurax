using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Jogos.Data;
using Jogos.Models;

namespace Jogos.Controllers
{
    public class DepartamentosController : Controller
    {
        private readonly ContextoJogos _banco;

        public DepartamentosController(ContextoJogos banco)
        {
            _banco = banco;
        }

        // GET: Departamentos
        public async Task<IActionResult> Index()
        {
            return View(await _banco.Departamentos.ToListAsync());
        }

        // GET: Departamentos/Detalhes/5
        public async Task<IActionResult> Detalhes(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var departamento = await _banco.Departamentos
                .FirstOrDefaultAsync(m => m.Id == id);
            if (departamento == null)
            {
                return NotFound();
            }

            return View(departamento);
        }

        // GET: Departamentos/Cadastrar
        public IActionResult Cadastrar()
        {
            return View();
        }

        // POST: Departamentos/Cadastrar
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Cadastrar([Bind("Id,Nome")] Departamento departamento)
        {
            if (ModelState.IsValid)
            {
                _banco.Add(departamento);
                await _banco.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(departamento);
        }

        // GET: Departamentos/Editar/5
        public async Task<IActionResult> Editar(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var departamento = await _banco.Departamentos.FindAsync(id);
            if (departamento == null)
            {
                return NotFound();
            }
            return View(departamento);
        }

        // POST: Departamentos/Editar/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Editar(int id, [Bind("Id,Nome")] Departamento departamento)
        {
            if (id != departamento.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _banco.Update(departamento);
                    await _banco.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DepartamentoExiste(departamento.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(departamento);
        }

        // GET: Departamentos/Excluir/5
        public async Task<IActionResult> Excluir(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var departamento = await _banco.Departamentos
                .FirstOrDefaultAsync(m => m.Id == id);
            if (departamento == null)
            {
                return NotFound();
            }

            return View(departamento);
        }

        // POST: Departamentos/Excluir/5
        [HttpPost, ActionName("Excluir")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ConfirmarExclusao(int id)
        {
            var departamento = await _banco.Departamentos.FindAsync(id);
            if (departamento == null) return NotFound();
            if (await _banco.Vendedores.AnyAsync(v => v.DepartamentoId == id))
            {
                ModelState.AddModelError(string.Empty, "Transfira ou exclua os vendedores vinculados antes de excluir este departamento.");
                return View("Excluir", departamento);
            }
            _banco.Departamentos.Remove(departamento);
            await _banco.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool DepartamentoExiste(int id)
        {
            return _banco.Departamentos.Any(e => e.Id == id);
        }
    }
}
