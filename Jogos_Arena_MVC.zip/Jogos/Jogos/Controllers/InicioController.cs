using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Jogos.Models;
using Jogos.Data;

namespace Jogos.Controllers
{
    public class InicioController : Controller
    {
        private readonly ContextoJogos _banco;

        public InicioController(ContextoJogos banco) { _banco = banco; }

        public IActionResult Index()
        {
            ViewData["TotalDepartamentos"] = _banco.Departamentos.Count();
            ViewData["TotalVendedores"] = _banco.Vendedores.Count();
            return View(_banco.Departamentos.OrderBy(jogo => jogo.Id).ToList());
        }

        public IActionResult Privacidade()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new Jogos.Models.ViewModels.ModeloErro { IdentificadorSolicitacao = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
