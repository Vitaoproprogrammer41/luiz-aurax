using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Diagnostics;
using Jogos.Models;
using Jogos.Models.ViewModels;
using Jogos.Services;
using Jogos.Services.Exceptions;

namespace Jogos.Controllers
{
    public class VendedoresController : Controller
    {
        private readonly ServicoVendedores _servicoVendedores;
        private readonly ServicoDepartamentos _servicoDepartamentos;

        public VendedoresController(ServicoVendedores servicoVendedores, ServicoDepartamentos servicoDepartamentos)
        {
            _servicoVendedores = servicoVendedores;
            _servicoDepartamentos = servicoDepartamentos;
        }

        public IActionResult Index()
        {
            var lista = _servicoVendedores.ListarTodos();
            return View(lista);
        }
        public IActionResult Cadastrar()
        {
            var departamentos = _servicoDepartamentos.ListarTodos();
            var formulario = new FormularioVendedor { Vendedor = new Vendedor(), Departamentos = departamentos };
            return View(formulario);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Cadastrar([Bind(Prefix = "Vendedor")] Vendedor vendedor)
        {
            if (!ModelState.IsValid) return View(new FormularioVendedor { Vendedor = vendedor, Departamentos = _servicoDepartamentos.ListarTodos() });
            _servicoVendedores.Inserir(vendedor);
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Excluir(int? id)
        {
            if (id == null)
            {
                return RedirectToAction(nameof(Error), new { mensagem = "Registro não encontrado." });
            }
            var registro = _servicoVendedores.BuscarPorId(id.Value);
            if (registro == null)
            {
                return RedirectToAction(nameof(Error), new { mensagem = "Registro não encontrado." });
            }
            return View(registro);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Excluir(int id)
        {
            _servicoVendedores.Remover(id);
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Detalhes(int? id)
        {
            if (id == null)
            {
                return RedirectToAction(nameof(Error), new { mensagem = "Registro não encontrado." });
            }
            var registro = _servicoVendedores.BuscarPorId(id.Value);
            if (registro == null)
            {
                return RedirectToAction(nameof(Error), new { mensagem = "Registro não encontrado." });
            }
            return View(registro);
        }

        public IActionResult Editar(int? id)
        {
            if (id == null)
            {
                return RedirectToAction(nameof(Error), new { mensagem = "Registro não encontrado." });
            }

            var registro = _servicoVendedores.BuscarPorId(id.Value);
            if (registro == null)
            {
                return RedirectToAction(nameof(Error), new { mensagem = "Registro não encontrado." });
            }

            List<Departamento> departamentos = _servicoDepartamentos.ListarTodos();
            FormularioVendedor formulario = new FormularioVendedor { Vendedor = registro, Departamentos = departamentos };
            return View(formulario);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Editar(int id, [Bind(Prefix = "Vendedor")] Vendedor vendedor)
        {
            if (!ModelState.IsValid) return View(new FormularioVendedor { Vendedor = vendedor, Departamentos = _servicoDepartamentos.ListarTodos() });
            if (id != vendedor.Id)
            {
                return BadRequest();
            }
            try
            {
                _servicoVendedores.Atualizar(vendedor);
                return RedirectToAction(nameof(Index));
            }
            catch (RegistroNaoEncontradoException)
            {
                return NotFound();
            }
            catch (ConcorrenciaBancoException)
            {
                return BadRequest();
            }
        }

        public IActionResult Error (string mensagem)
        {
            var formulario = new ModeloErro()
            {
                Mensagem = mensagem,
                IdentificadorSolicitacao = Activity.Current?.Id ?? HttpContext.TraceIdentifier
            };
            return View("Error", formulario);
        }
    }
}