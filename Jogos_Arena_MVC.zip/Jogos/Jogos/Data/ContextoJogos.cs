using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Jogos.Models;

namespace Jogos.Data
{
    public class ContextoJogos : DbContext
    {
        public ContextoJogos (DbContextOptions<ContextoJogos> opcoes)
            : base(opcoes)
        {
        }

        public DbSet<Departamento> Departamentos { get; set; }
        public DbSet<Vendedor> Vendedores { get; set; }
        public DbSet<RegistroVenda>  RegistroVenda { get; set; }
    }
}
