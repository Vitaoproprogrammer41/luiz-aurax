using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Jogos.Models;
using Jogos.Models.Enums;

namespace Jogos.Data
{
    public class ServicoDadosIniciais
    {
        private ContextoJogos _banco;

        public ServicoDadosIniciais(ContextoJogos banco)
        {
            _banco = banco;
        }

        public void Popular()
        {
            if (_banco.Departamentos.Any() ||
                _banco.Vendedores.Any() ||
                _banco.RegistroVenda.Any())
            {
                return; // DB has been seeded
            }

            Departamento jogo1 = new Departamento(1, "Red Dead 2");
            Departamento jogo2 = new Departamento(2, "GTA VI");
            Departamento jogo3 = new Departamento(3, "GTA V");
            Departamento jogo4 = new Departamento(4, "Mortal Kombat 11");
            Departamento jogo5 = new Departamento(5, "Sonic Frontiers");
            Departamento jogo6 = new Departamento(6, "Tekken 7");
            Departamento jogo7 = new Departamento(7, "Street Fight");
            Departamento jogo8 = new Departamento(8, "Bomberman");
            Departamento jogo9 = new Departamento(9, "RESIDENT EVIL");

            Vendedor vendedor1 = new Vendedor(1, "Bob Brown", "bob@gmail.com", new DateTime(1998, 4, 21), 1000.0, jogo2);
            Vendedor vendedor2 = new Vendedor(2, "Maria Green", "maria@gmail.com", new DateTime(1979, 12, 31), 4000.0, jogo4);
            Vendedor vendedor3 = new Vendedor(3, "Alex Gray", "alex@gmail.com", new DateTime(1988, 1, 15), 2000.0, jogo1);
            Vendedor vendedor4 = new Vendedor(4, "Martina Red", "martina@gmail.com", new DateTime(1993, 11, 30), 1500.0, jogo3);
            Vendedor vendedor5 = new Vendedor(5, "Donald Blue", "donald@gmail.com", new DateTime(2000, 1, 9), 9000.0, jogo2);
            Vendedor vendedor6 = new Vendedor(6, "Arthur Yellow", "arthur@gmail.com", new DateTime(1997, 3, 4), 750.0, jogo4);

            RegistroVenda venda1 = new RegistroVenda(1, new DateTime(2018, 05, 25), 11000.0, SituacaoVenda.Faturada, vendedor1);
            RegistroVenda venda2 = new RegistroVenda(2, new DateTime(2018, 06, 07), 1000.0, SituacaoVenda.Faturada, vendedor2);
            RegistroVenda venda3 = new RegistroVenda(3, new DateTime(2018, 04, 21), 6700.0, SituacaoVenda.Faturada, vendedor3);
            RegistroVenda venda4 = new RegistroVenda(4, new DateTime(2018, 09, 25), 15000.0, SituacaoVenda.Faturada, vendedor4);
            RegistroVenda venda5 = new RegistroVenda(5, new DateTime(2018, 12, 12), 16000.0, SituacaoVenda.Faturada, vendedor2);
            RegistroVenda venda6 = new RegistroVenda(6, new DateTime(2018, 07, 31), 17000.0, SituacaoVenda.Faturada, vendedor3);
            RegistroVenda venda7 = new RegistroVenda(7, new DateTime(2018, 10, 28), 18000.0, SituacaoVenda.Faturada, vendedor5);

            _banco.Departamentos.AddRange(jogo1, jogo2, jogo3, jogo4, jogo5, jogo6, jogo7, jogo8, jogo9);

            _banco.Vendedores.AddRange(vendedor1, vendedor2, vendedor3, vendedor4, vendedor5, vendedor6);

            _banco.RegistroVenda.AddRange(venda1, venda2, venda3, venda4, venda5, venda6, venda7);

            _banco.SaveChanges();
        }
    }
}
