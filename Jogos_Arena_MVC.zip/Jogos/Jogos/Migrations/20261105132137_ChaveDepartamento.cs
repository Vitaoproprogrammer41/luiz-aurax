using Microsoft.EntityFrameworkCore.Migrations;

namespace Jogos.Migrations
{
    public partial class ChaveDepartamento : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Vendedores_Departamentos_DepartamentoAnteriorId",
                table: "Vendedores");

            migrationBuilder.DropIndex(
                name: "IX_Vendedores_DepartamentoAnteriorId",
                table: "Vendedores");

            migrationBuilder.DropColumn(
                name: "DepartamentoAnteriorId",
                table: "Vendedores");

            migrationBuilder.AddColumn<int>(
                name: "DepartamentoId",
                table: "Vendedores",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Vendedores_DepartamentoId",
                table: "Vendedores",
                column: "DepartamentoId");

            migrationBuilder.AddForeignKey(
                name: "FK_Vendedores_Departamentos_DepartamentoId",
                table: "Vendedores",
                column: "DepartamentoId",
                principalTable: "Departamentos",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Vendedores_Departamentos_DepartamentoId",
                table: "Vendedores");

            migrationBuilder.DropIndex(
                name: "IX_Vendedores_DepartamentoId",
                table: "Vendedores");

            migrationBuilder.DropColumn(
                name: "DepartamentoId",
                table: "Vendedores");

            migrationBuilder.AddColumn<int>(
                name: "DepartamentoAnteriorId",
                table: "Vendedores",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Vendedores_DepartamentoAnteriorId",
                table: "Vendedores",
                column: "DepartamentoAnteriorId");

            migrationBuilder.AddForeignKey(
                name: "FK_Vendedores_Departamentos_DepartamentoAnteriorId",
                table: "Vendedores",
                column: "DepartamentoAnteriorId",
                principalTable: "Departamentos",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
