using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Jogos.Models.Enums
{
    public enum SituacaoVenda : int
    {

        Pendente = 0,
        Faturada = 1,
        Cancelada = 2
    }
}
