using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Jogos.Models.Enums;

namespace Jogos.Models
{
    public class RegistroVenda
    {
        public int Id { get; set; }
        public DateTime Data { get; set; }
        public double Valor { get; set; }
        public SituacaoVenda Situacao { get; set; }
        public Vendedor Vendedor { get; set; }
        public RegistroVenda()
        {

        }

        public RegistroVenda(int id, DateTime dataVenda, double valor, SituacaoVenda situacao, Vendedor vendedor)
        {
            Id = id;
            Data = dataVenda;
            Valor = valor;
            Situacao = situacao;
            Vendedor = vendedor;
        }
    }
    }
