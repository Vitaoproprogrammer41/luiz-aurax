using System;

namespace Jogos.Models.ViewModels
{
    public class ModeloErro
    {
        public string IdentificadorSolicitacao { get; set; }
        public string Mensagem { get; set; }

        public bool ExibirIdentificador => !string.IsNullOrEmpty(IdentificadorSolicitacao);
    }
}