using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Jogos
{
    public class Program
    {
        public static void Main(string[] argumentos)
        {
            CreateWebHostBuilder(argumentos).Build().Run();
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] argumentos) =>
            WebHost.CreateDefaultBuilder(argumentos)
                .UseStartup<Startup>();
    }
}
