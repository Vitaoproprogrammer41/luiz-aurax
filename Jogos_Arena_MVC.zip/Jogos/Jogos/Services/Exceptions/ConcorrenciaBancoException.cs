using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Jogos.Services.Exceptions
{
    public class ConcorrenciaBancoException : ApplicationException
    {
        public ConcorrenciaBancoException(string mensagem) : base(mensagem)
        {

        }
    }
}
