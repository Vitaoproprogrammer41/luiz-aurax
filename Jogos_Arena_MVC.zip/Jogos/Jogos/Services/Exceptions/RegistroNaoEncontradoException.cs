using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Jogos.Services.Exceptions
{
    public class RegistroNaoEncontradoException : ApplicationException
    {
        public RegistroNaoEncontradoException(string mensagem) : base(mensagem)
        {

        }
    }
}
