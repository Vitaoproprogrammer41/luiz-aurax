using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Jogos.Data;
using Jogos.Models;

namespace Jogos.Services
{
    public class ServicoDepartamentos
    {
        private readonly ContextoJogos _banco;

        public ServicoDepartamentos(ContextoJogos banco)
        {
            _banco = banco;
        }

        public List<Departamento> ListarTodos()
        {
            return _banco.Departamentos.OrderBy(x => x.Nome).ToList();
        }
    }
}
