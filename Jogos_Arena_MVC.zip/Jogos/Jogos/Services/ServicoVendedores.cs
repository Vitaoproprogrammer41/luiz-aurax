using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Jogos.Data;
using Jogos.Models;
using Microsoft.EntityFrameworkCore;
using Jogos.Services.Exceptions;

namespace Jogos.Services
{
    public class ServicoVendedores
    {
        private readonly ContextoJogos _banco;

        public ServicoVendedores(ContextoJogos banco)
        {
            _banco = banco;
        }

        public List<Vendedor> ListarTodos()
        {
            return _banco.Vendedores.Include(registro => registro.Departamento).ToList();
        }


        public void Inserir(Vendedor registro)
        {
          
            _banco.Add(registro);
            _banco.SaveChanges();
        }

        public Vendedor BuscarPorId(int id)
        {
            return _banco.Vendedores.Include(registro => registro.Departamento).FirstOrDefault(registro => registro.Id == id); 
        }
        public void Remover(int id)
        {
            var registro = _banco.Vendedores.Include(v => v.Vendas).FirstOrDefault(v => v.Id == id);
            if (registro == null) return;
            _banco.Vendedores.Remove(registro);
            _banco.SaveChanges();
        }

        public void Atualizar(Vendedor registro)
        {
            if(!_banco.Vendedores.Any(x => x.Id == registro.Id))
            {
                throw new RegistroNaoEncontradoException("Registro não encontrado");
            }
            try
            {
                _banco.Update(registro);
                _banco.SaveChanges();
            }
            catch (DbUpdateConcurrencyException e)
            {
                throw new ConcorrenciaBancoException(e.Message);
            }
        }
    }
}
