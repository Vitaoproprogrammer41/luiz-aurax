using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Jogos.Data;
using Jogos.Services;

namespace Jogos
{
    public class Startup
    {
        public Startup(IConfiguration configuracao)
        {
            Configuracao = configuracao;
        }

        public IConfiguration Configuracao { get; }

        // This method gets called by the runtime. Use this method to add servicos to the container.
        public void ConfigureServices(IServiceCollection servicos)
        {
            servicos.Configure<CookiePolicyOptions>(opcoes =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                opcoes.CheckConsentNeeded = banco => true;
                opcoes.MinimumSameSitePolicy = SameSiteMode.None;
            });


            servicos.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);

            servicos.AddDbContext<ContextoJogos>(opcoes =>
            opcoes.UseMySql(Configuracao.GetConnectionString("ContextoJogos"), construtor =>
                        construtor.MigrationsAssembly("Jogos")));

            servicos.AddScoped<ServicoDadosIniciais>();
            servicos.AddScoped<ServicoVendedores>();
            servicos.AddScoped<ServicoDepartamentos>();
        }


        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.

        public void Configure(IApplicationBuilder aplicacao, IHostingEnvironment ambiente)
        {
            if (ambiente.IsDevelopment())
            {
                aplicacao.UseDeveloperExceptionPage();
                using (var escopo = aplicacao.ApplicationServices.CreateScope())
                {
                    var banco = escopo.ServiceProvider.GetRequiredService<ContextoJogos>();
                    banco.Database.Migrate();
                    escopo.ServiceProvider.GetRequiredService<ServicoDadosIniciais>().Popular();
                }
            }
            else
            {
                aplicacao.UseExceptionHandler("/Inicio/Error");
                aplicacao.UseHsts();
            }

            aplicacao.UseHttpsRedirection();
            aplicacao.UseStaticFiles();
            aplicacao.UseCookiePolicy();

            aplicacao.UseMvc(rotas =>
            {
                rotas.MapRoute(
                    name: "default",
                    template: "{controller=Inicio}/{action=Index}/{id?}");
            });
        }
    }
}
