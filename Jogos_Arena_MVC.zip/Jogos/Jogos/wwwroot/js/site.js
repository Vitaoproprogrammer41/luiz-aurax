(function () {
    var busca = document.getElementById('busca-vendedores');
    if (!busca) return;
    busca.addEventListener('input', function () {
        var termo = busca.value.toLowerCase().trim();
        var registros = document.querySelectorAll('#tabela-vendedores tbody tr');
        var totalVisivel = 0;
        for (var indice = 0; indice < registros.length; indice++) {
            var registro = registros[indice];
            var corresponde = registro.textContent.toLowerCase().indexOf(termo) >= 0;
            registro.hidden = !corresponde;
            if (corresponde) totalVisivel++;
        }
        document.getElementById('sem-resultados').hidden = totalVisivel !== 0;
    });
})();
