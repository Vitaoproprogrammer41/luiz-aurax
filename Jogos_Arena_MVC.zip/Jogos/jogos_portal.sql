-- Importacao manual para um banco jogos_portal vazio, antes de executar o MVC.
-- Nao execute sobre um banco jogos_portal que ja tenha tabelas.
CREATE DATABASE IF NOT EXISTS `jogos_portal` CHARACTER SET utf8mb4;
USE `jogos_portal`;

CREATE TABLE `Departamentos` (
  `Id` INT NOT NULL AUTO_INCREMENT,
  `Nome` LONGTEXT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB;

CREATE TABLE `Vendedores` (
  `Id` INT NOT NULL AUTO_INCREMENT,
  `Nome` LONGTEXT NULL,
  `Email` LONGTEXT NULL,
  `DataNascimento` DATETIME(6) NOT NULL,
  `SalarioBase` DOUBLE NOT NULL,
  `DepartamentoId` INT NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_Vendedores_DepartamentoId` (`DepartamentoId`),
  CONSTRAINT `FK_Vendedores_Departamentos_DepartamentoId` FOREIGN KEY (`DepartamentoId`) REFERENCES `Departamentos` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `RegistroVenda` (
  `Id` INT NOT NULL AUTO_INCREMENT,
  `Data` DATETIME(6) NOT NULL,
  `Valor` DOUBLE NOT NULL,
  `Situacao` INT NOT NULL,
  `VendedorId` INT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_RegistroVenda_VendedorId` (`VendedorId`),
  CONSTRAINT `FK_RegistroVenda_Vendedores_VendedorId` FOREIGN KEY (`VendedorId`) REFERENCES `Vendedores` (`Id`) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE `__EFMigrationsHistory` (
  `MigrationId` VARCHAR(150) NOT NULL,
  `ProductVersion` VARCHAR(32) NOT NULL,
  PRIMARY KEY (`MigrationId`)
) ENGINE=InnoDB;

START TRANSACTION;
INSERT INTO `Departamentos` (`Id`, `Nome`) VALUES
(1, 'Red Dead 2'), (2, 'GTA VI'), (3, 'GTA V'),
(4, 'Mortal Kombat 11'), (5, 'Sonic Frontiers'), (6, 'Tekken 7'),
(7, 'Street Fight'), (8, 'Bomberman'), (9, 'RESIDENT EVIL');

INSERT INTO `Vendedores` (`Id`, `Nome`, `Email`, `DataNascimento`, `SalarioBase`, `DepartamentoId`) VALUES
(1, 'Bob Brown', 'bob@gmail.com', '1998-04-21', 1000, 2),
(2, 'Maria Green', 'maria@gmail.com', '1979-12-31', 4000, 4),
(3, 'Alex Gray', 'alex@gmail.com', '1988-01-15', 2000, 1),
(4, 'Martina Red', 'martina@gmail.com', '1993-11-30', 1500, 3),
(5, 'Donald Blue', 'donald@gmail.com', '2000-01-09', 9000, 2),
(6, 'Arthur Yellow', 'arthur@gmail.com', '1997-03-04', 750, 4);

INSERT INTO `RegistroVenda` (`Id`, `Data`, `Valor`, `Situacao`, `VendedorId`) VALUES
(1, '2018-05-25', 11000, 1, 1), (2, '2018-06-07', 1000, 1, 2),
(3, '2018-04-21', 6700, 1, 3), (4, '2018-09-25', 15000, 1, 4),
(5, '2018-12-12', 16000, 1, 2), (6, '2018-07-31', 17000, 1, 3),
(7, '2018-10-28', 18000, 1, 5);

INSERT INTO `__EFMigrationsHistory` (`MigrationId`, `ProductVersion`) VALUES
('20261001103241_inicio', '2.1.14-servicing-32113'),
('20261020104826_OutrasEntidades', '2.1.14-servicing-32113'),
('20261105132137_ChaveDepartamento', '2.1.14-servicing-32113');
COMMIT;
